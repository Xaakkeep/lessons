1. Text 

2. Text

3. Text
4. Text