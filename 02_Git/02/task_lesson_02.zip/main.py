def Hello(text):
    print(f'Hello World {text}')

def max(a,b):
    if a>b:
        print(a)
    else:
        print(b)

def summa(a,b):
    print(f'{a}+{b}')

def hello_text(name):
    print(f'Hello {name}')